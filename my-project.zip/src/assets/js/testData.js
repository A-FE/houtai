const testData = {
  'ID00001':{
    title: '王小虎',
    type:'测试活动',
    status:'已结束',
    readNum:200,
    signUpNum:100,
    auditNum:100,
    ruleForm: {},
    signForm: {},
    shareForm: {},
    selfForm: {},
  },
}
export default  testData
